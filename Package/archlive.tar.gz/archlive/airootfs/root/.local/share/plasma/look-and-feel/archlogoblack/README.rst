archlogoblack
=============

A splash theme for KDE 5 based on archlogogreen

.. image:: https://gitlab.com/menelkir/archlogoblack/raw/master/contents/previews/splash.png

===========
Themes used
===========

:archlogogreen https://www.opendesktop.org/p/997749/

=============
How to donate
=============

If you find this repo useful (don't forget to pay a visit to the related
repos too), you can buy me a beer:

:BTC: 3ECzX5UhcFSRv6gBBYLNBc7zGP9UA5Ppmn

:ETH: 0x7E17Ac09Fa7e6F80284a75577B5c1cbaAD566C1c

